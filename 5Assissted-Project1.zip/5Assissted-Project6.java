package com.seleniumproject;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.io.FileHandler;

public class screenshootproblem {

	public static void main(String[] args) {
		 System.setProperty("webdriver.chrome.driver", "C:\\Users\\RAMYA PRAKASH\\selenium\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
			
	     WebDriver driver= new ChromeDriver();
		driver.manage().window().maximize();
		
		driver.get("https://www.instagram.com/");
		
		TakesScreenshot screenshot=(TakesScreenshot) driver;
		File src= screenshot.getScreenshotAs(OutputType.FILE);
		try {
			FileHandler.copy(src, new File("C:\\Users\\RAMYA PRAKASH\\OneDrive\\Desktop\\ramya\\Mphasis\\testing//instagram.png"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		driver.close();
		

	}

}
