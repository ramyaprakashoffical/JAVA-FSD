Step 3.6.1: Selecting the EBS volume you want to detach
●	Choose the bucket
●	Select Detach Volume option
 


Step 3.6.2: Detaching the volume
●	Select Yes once the confirmation pop-up appears
●	Once detached, the volume will be labeled as Available

 

