
●Delete an EBS volume

 Selecting the EBS volume you want to delete
 Deleting the volume
 Pushing the file to GitHub repositories

Step 1: Selecting the EBS volume you want to delete
 

Step 2: Deleting the volume
 




