Step 3.4.1: Selecting the volume tab in the EC2 dashboard
 
Step 3.4.2: Creating a new volume by clicking on Create 
 
Step 3.4.3: Selecting the volume type according to the project requirement 

Step 3.4.4: Creating a new volume by specifying the size and defining the zone

Step 3.4.5: Verifying the new volume created on the volume console and its availability

