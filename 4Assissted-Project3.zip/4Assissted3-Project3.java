●	Disable a button using disabled attribute of the element. Set the disabled to false by binding value to attr.disabled attribute property.
●	Open Visual Studio Code
●	Add the following code to  Product-list.component.html.
<button [attr.disabled]=”true” class="btn btn-primary" (click)='toggleImage()'>
      Show Image
  </button>
