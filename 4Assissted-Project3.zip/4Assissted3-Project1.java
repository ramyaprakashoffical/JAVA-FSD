Creating Angular components

●	Open Visual Studio Code
●	Navigate to the created angular-app project folder.
●	Create a folder called products inside the src/app folder.
●	Create a product-list.component.html file in the products folder.
●	Add the following code to product-list.component.html.
<h1> Product List Page </h1>
●	Create a file called  product-list.component.ts.
 


  
