<div class="container"> 
    
    <h2>Welcome to Event Management App</h2> 
    <h4>login</h4> 
    <form (ngSubmit)="login()"> 
    <div class="form-group"> 
    <label for="username">Username:</label> 
    <input type="text" id="username" name="username" class="form-control" 
    [(ngModel)]="username" required> 
    </div> 
    <div class="form-group"> 
    <label for="password">Password:</label> 
    <input type="password" id="password" name="password" 
    class="formcontrol" 
    [(ngModel)]="password" required> 
    </div> 
    <div class="alert alert-danger" *ngIf="errorMessage"></div> 
    <button type="submit" class="btn btn-primary">Login</button> 
    </form> </div>

export class LoginComponent {

  username: string =""; 
  password: string | undefined; 
  errorMessage: string | undefined; 
  constructor(private router: Router, private http: HttpClient) 
  {

  }
  
  login() 
{ 
if (this.username === 'ram' && this.password === 'ram@123') {

} 
else { 
this.errorMessage = 'Invalid username or password'; 
} 

}

}
