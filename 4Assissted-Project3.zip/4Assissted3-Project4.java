<h2>Event Binding</h2>

<input type="button" value="click here" (click)="test()" />

<input type="text" [(ngModel)]="name" />

export class SampleComponent {
  name:String="Ramya"
  age:number=22

  test():void{
    this.name="ram"
    this.age=30
  }

}